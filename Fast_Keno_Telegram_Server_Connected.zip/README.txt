FAST KENO - TELEGRAM + ADMIN SERVER

1) Install Node.js 18+.
2) Open this folder in terminal.
3) Run: npm install
4) Set environment variables:
   BOT_TOKEN=your Telegram bot token
   ADMIN_KEY=your private admin key
   PORT=3000 (optional)
5) Run: npm start
6) Put the folder on an HTTPS server for Telegram Mini App use.
7) Set your Telegram Bot Mini App/Web App URL to the HTTPS URL of this server.
8) Open the Admin Panel at /Fast_Keno_Admin_Panel.html and enter the same ADMIN_KEY when prompted.

IMPORTANT:
- Never put BOT_TOKEN inside A.html or the Admin Panel.
- The server/data/db.json file is the shared database for this starter package.
- For production with many users, use a managed database (PostgreSQL/Supabase) and HTTPS.
- The original A.html game UI and original Admin Panel are preserved; the connection layer is added around them.

API:
GET  /api/health
POST /api/player/sync
GET  /api/player/me
POST /api/player/bet
POST /api/player/refund
POST /api/player/win
GET  /api/rounds/latest
GET  /api/admin/state       (admin key)
POST /api/admin/player      (admin key)
POST /api/admin/balance     (admin key)
DELETE /api/admin/player/:id (admin key)
POST /api/admin/draw        (admin key)
POST /api/admin/payouts     (admin key)
DELETE /api/admin/history   (admin key)

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN || '';
const ADMIN_KEY = process.env.ADMIN_KEY || 'CHANGE_ME_ADMIN_KEY';
const DB_FILE = path.join(__dirname, 'data', 'db.json');
const PUBLIC_DIR = __dirname;

app.use(cors());
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(PUBLIC_DIR));

function defaultDB(){return {players:{},rounds:[],payouts:{1:7,2:20,3:100,4:160,5:300,6:1000,7:2000,8:4000,9:10000,10:20000}}}
function loadDB(){
  try{return JSON.parse(fs.readFileSync(DB_FILE,'utf8'))}catch(e){
    const db=defaultDB(); fs.mkdirSync(path.dirname(DB_FILE),{recursive:true}); fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2)); return db;
  }
}
function saveDB(db){fs.mkdirSync(path.dirname(DB_FILE),{recursive:true});fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2))}
let db=loadDB();
function idFromUser(u){return 'TG-'+String(u.id)}
function authAdmin(req,res,next){
  const key=req.headers['x-admin-key'] || req.query.key;
  if(!key || key!==ADMIN_KEY)return res.status(401).json({ok:false,error:'Admin authentication required'});
  next();
}
function validateTelegramInitData(initData){
  if(!BOT_TOKEN || !initData)return null;
  const params=new URLSearchParams(initData);
  const hash=params.get('hash'); if(!hash)return null;
  params.delete('hash');
  const pairs=[...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
  const secret=crypto.createHmac('sha256','WebAppData').update(BOT_TOKEN).digest();
  const check=crypto.createHmac('sha256',secret).update(pairs).digest('hex');
  if(!crypto.timingSafeEqual(Buffer.from(check),Buffer.from(hash)))return null;
  const user=params.get('user');
  if(!user)return null;
  try{return JSON.parse(user)}catch(e){return null}
}
function getUser(req){
  const user=validateTelegramInitData(req.body?.initData || req.headers['x-telegram-init-data'] || '');
  if(user)return user;
  const dev=req.headers['x-player-id'] || req.body?.playerId;
  if(dev && String(dev).length<=80)return {id:String(dev),first_name:'Player',last_name:''};
  return null;
}
function ensurePlayer(user){
  const id=idFromUser(user);
  if(!db.players[id])db.players[id]={id,name:[user.first_name,user.last_name].filter(Boolean).join(' ')||'Player',balance:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
  return db.players[id];
}
function random20(){const a=Array.from({length:80},(_,i)=>i+1);for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a.slice(0,20)}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Fast Keno API',time:new Date().toISOString()}));

app.post('/api/player/sync',(req,res)=>{
  const user=getUser(req); if(!user)return res.status(401).json({ok:false,error:'Valid Telegram Mini App data or player ID required'});
  const p=ensurePlayer(user); p.updatedAt=new Date().toISOString(); saveDB(db);
  res.json({ok:true,player:p,payouts:db.payouts,latestRound:db.rounds[0]||null});
});
app.get('/api/player/me',(req,res)=>{
  const user=getUser(req); if(!user)return res.status(401).json({ok:false,error:'Player authentication required'});
  const p=ensurePlayer(user); saveDB(db); res.json({ok:true,player:p,payouts:db.payouts,latestRound:db.rounds[0]||null});
});
app.post('/api/player/bet',(req,res)=>{
  const user=getUser(req); if(!user)return res.status(401).json({ok:false,error:'Player authentication required'});
  const p=ensurePlayer(user); const amount=Number(req.body.amount); if(!Number.isFinite(amount)||amount<2)return res.status(400).json({ok:false,error:'Invalid bet'});
  if(p.balance<amount)return res.status(400).json({ok:false,error:'Insufficient balance'});
  p.balance-=amount;p.updatedAt=new Date().toISOString();saveDB(db);res.json({ok:true,balance:p.balance});
});
app.post('/api/player/refund',(req,res)=>{
  const user=getUser(req); if(!user)return res.status(401).json({ok:false,error:'Player authentication required'});
  const p=ensurePlayer(user); const amount=Number(req.body.amount); if(!Number.isFinite(amount)||amount<0)return res.status(400).json({ok:false,error:'Invalid amount'});
  p.balance+=amount;p.updatedAt=new Date().toISOString();saveDB(db);res.json({ok:true,balance:p.balance});
});
app.post('/api/player/win',(req,res)=>{
  const user=getUser(req); if(!user)return res.status(401).json({ok:false,error:'Player authentication required'});
  const p=ensurePlayer(user); const amount=Number(req.body.amount); if(!Number.isFinite(amount)||amount<0)return res.status(400).json({ok:false,error:'Invalid amount'});
  p.balance+=amount;p.updatedAt=new Date().toISOString();saveDB(db);res.json({ok:true,balance:p.balance});
});

app.get('/api/rounds/latest',(req,res)=>res.json({ok:true,round:db.rounds[0]||null}));

app.get('/api/admin/state',authAdmin,(req,res)=>res.json({ok:true,players:Object.values(db.players),rounds:db.rounds,payouts:db.payouts}));
app.post('/api/admin/player',authAdmin,(req,res)=>{
  const id=String(req.body.id||'').trim();if(!id)return res.status(400).json({ok:false,error:'Player ID required'});
  const old=db.players[id]||{};const balance=Number(req.body.balance);db.players[id]={id,name:String(req.body.name||old.name||'Player'),balance:Number.isFinite(balance)?Math.max(0,balance):Number(old.balance||0),createdAt:old.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};saveDB(db);res.json({ok:true,player:db.players[id]});
});
app.post('/api/admin/balance',authAdmin,(req,res)=>{
  const id=String(req.body.id||'').trim();const amount=Number(req.body.amount);const sign=Number(req.body.sign);
  if(!db.players[id])return res.status(404).json({ok:false,error:'Player not found'});if(!Number.isFinite(amount)||amount<0||![1,-1].includes(sign))return res.status(400).json({ok:false,error:'Invalid balance change'});
  db.players[id].balance=Math.max(0,db.players[id].balance+sign*amount);db.players[id].updatedAt=new Date().toISOString();saveDB(db);res.json({ok:true,player:db.players[id]});
});
app.delete('/api/admin/player/:id',authAdmin,(req,res)=>{delete db.players[req.params.id];saveDB(db);res.json({ok:true})});
app.post('/api/admin/draw',authAdmin,(req,res)=>{
  let nums=Array.isArray(req.body.numbers)?req.body.numbers.map(Number):random20();nums=[...new Set(nums)].filter(n=>Number.isInteger(n)&&n>=1&&n<=80).slice(0,20);if(nums.length!==20)return res.status(400).json({ok:false,error:'Exactly 20 unique numbers required'});
  const round={id:30000+db.rounds.length+1,time:new Date().toISOString(),numbers:nums};db.rounds.unshift(round);db.rounds=db.rounds.slice(0,500);saveDB(db);res.json({ok:true,round});
});
app.post('/api/admin/payouts',authAdmin,(req,res)=>{for(let i=1;i<=10;i++){const v=Number(req.body[i]);if(Number.isFinite(v)&&v>0)db.payouts[i]=v}saveDB(db);res.json({ok:true,payouts:db.payouts})});
app.delete('/api/admin/history',authAdmin,(req,res)=>{db.rounds=[];saveDB(db);res.json({ok:true})});

app.get('*',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'A.html')));
app.listen(PORT,()=>console.log(`Fast Keno server running on http://localhost:${PORT}`));
